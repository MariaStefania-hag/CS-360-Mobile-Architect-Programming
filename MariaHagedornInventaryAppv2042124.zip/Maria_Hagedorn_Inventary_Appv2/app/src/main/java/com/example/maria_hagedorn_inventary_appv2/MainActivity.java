package com.example.maria_hagedorn_inventary_appv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText edUsername, edUserPassword;
    Button btn1, btn2, btn3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edUsername = findViewById(R.id.UserEmail);
        edUserPassword = findViewById(R.id.UserPass);
        btn1 = findViewById(R.id.buttonLogin);
        btn2 = findViewById(R.id.buttonNewUser);
        btn3 = findViewById(R.id.buttonResetPass);


        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, forgotpassword.class));
            }
        });


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = edUsername.getText().toString();
                String password = edUserPassword.getText().toString();
                Database db = new Database(getApplicationContext(), "Maria_Hagedorn_Inventary_Appv2", null, 1);
                if (username.length() == 0 || password.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Please enter username and password or Register.", Toast.LENGTH_SHORT).show();
                } else {
                    if (db.login(username, password) == 1) {
                        Toast.makeText(getApplicationContext(), "Login Success!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this, ActivityActivity.class));

                    }
                }
                btn2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(MainActivity.this, MainActivity2.class));


                    }


                });

            }


        });


    }
}

