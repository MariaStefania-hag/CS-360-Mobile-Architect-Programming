package com.example.maria_hagedorn_inventary_appv2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding);
    }
}