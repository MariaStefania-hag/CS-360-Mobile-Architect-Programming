package com.example.maria_hagedorn_inventary_appv2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity {

    EditText edUsername, edEmail, edPassword, edConfirm;

    Button btn1, btn2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edUsername = findViewById(R.id.UserEmail);
        edEmail = findViewById(R.id.UserEmail);
        edPassword = findViewById(R.id.EnterPassword);
        edConfirm = findViewById(R.id.UserPass);
        btn1 = findViewById(R.id.RetrievePass);
        btn2 = findViewById(R.id.buttonDelete);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this, MainActivity.class));


            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edUsername.getText().toString();
                String email = edEmail.getText().toString();
                String password = edPassword.getText().toString();
                String confirm = edConfirm.getText().toString();
                Database db = new Database(getApplicationContext(), "Maria_Hagedorn_Inventary_Appv2",null,1);
                if (username.length() == 0 || password.length() == 0 || email.length() == 0 || confirm.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Please enter detail.", Toast.LENGTH_SHORT).show();
                } else {
                    if (password.compareTo(confirm) == 0) {
                        if (isValid(password)) {
                            db.register(username,email,password);
                            Toast.makeText(getApplicationContext(), "Record Inserted", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(MainActivity2.this, MainActivity.class));
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Password must contain at least 8 characters, " +
                                    "having letters, symbol and special character", Toast.LENGTH_SHORT).show();
                        }
                    }

                    else{
                        Toast.makeText(getApplicationContext(), "Password don't match!", Toast.LENGTH_SHORT).show();
                    }
                }


            }



        });
    }


    public static boolean isValid(String passwordhere) {
        int f1 = 0, f2 = 0, f3 = 0;
        if (passwordhere.length() < 8) {
            return false;

        } else {
            for (int p = 0; p < passwordhere.length(); p++) {
                if (Character.isLetter(passwordhere.charAt(p))) {
                    f1=1;
                }
            }

            for (int r = 0; r <passwordhere.length(); r++){
                if (Character.isDigit(passwordhere.charAt(r))) {
                    f2=1;
                }

            }
            for (int s =0; s <passwordhere.length(); s++ ){
                char c = passwordhere.charAt(s);
                if (c>33&&c<=46||c==64) {
                    f3=1;
                }
            }
            return f1 == 1 && f2 == 1 && f3 == 1;
        }

    }

}

