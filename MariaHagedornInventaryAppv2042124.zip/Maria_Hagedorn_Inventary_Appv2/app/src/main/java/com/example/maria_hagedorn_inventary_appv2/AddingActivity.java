package com.example.maria_hagedorn_inventary_appv2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddingActivity extends AppCompatActivity {

    //Reference to button and edit text

    MyDatabaseHelper myDB;
    ListView listView;
    ArrayList<String> Id, Description, Quantity;

    EditText Item_Description, Item_Quantity;
    Button btn1, btn2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding);


        Item_Description = findViewById(R.id.editTextItemDescription);
        Item_Quantity = findViewById(R.id.editTextItemQuantity);
        btn1 = findViewById(R.id.Addbtn);
        btn2 = findViewById(R.id.Viewbtn);
        listView = findViewById(R.id.bodyListView);

        //Button Listeners

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddingActivity.this);
                myDB.addMethod(Item_Description.getText().toString().trim(),
                        String.valueOf(Integer.valueOf(Item_Quantity.getText().toString().trim())));
                Toast.makeText(AddingActivity.this, "Added!", Toast.LENGTH_SHORT).show();

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddingActivity.this, ItemMainActivity3.class));

            }
        });
    }
}