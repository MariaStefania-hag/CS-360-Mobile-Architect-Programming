package com.example.maria_hagedorn_inventary_appv2;


import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class forgotpassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);


        Button btn1, btn2;
        EditText edEmail;


        btn1 = findViewById(R.id.RetrievePass);
        btn2 = findViewById(R.id.buttonDelete);
        edEmail = findViewById(R.id.UserEmail);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(forgotpassword.this, MainActivity.class));


            }


        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(forgotpassword.this, MainActivity.class));



            }
        });


    }
}








